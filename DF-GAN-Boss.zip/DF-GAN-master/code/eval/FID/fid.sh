path1=../../../code/vals/coco
path2=../../../data/coco/npz/coco_val256_FIDK0.npz

python fid_score.py --path1 $path1 --path2 $path2
